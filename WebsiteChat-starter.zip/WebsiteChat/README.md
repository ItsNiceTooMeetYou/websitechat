# WebsiteChat.Com — starter chat room

A responsive single-room chat website with display names, real-time messages (Firebase), and an optional friendly auto-reply bot.

## What works right away

Open `index.html` in a browser to try **Demo mode**. You can choose a display name, chat, and see the sample bot reply. Demo messages are only stored in the current browser tab and are **not** shared with other people.

## Make it live for everyone (Firebase + GitHub Pages)

You need a free GitHub account and a Firebase project. You do not need a paid server for this starter.

### 1. Create the Firebase project
1. Go to https://console.firebase.google.com/ and create a project.
2. In **Build → Authentication → Sign-in method**, enable **Anonymous** sign-in.
3. In **Build → Firestore Database**, create a database.
4. In Project settings → General → Your apps, add a **Web app** and copy its Firebase config.

### 2. Add your Firebase config
Open `index.html`. Find this line near the top of the script:

```js
const firebaseConfig = null;
```

Replace `null` with your Firebase config object, like:

```js
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  appId: "YOUR_APP_ID"
};
```

Use the exact values Firebase gives your project. Firebase's web config is not a server secret, but database access must be protected by rules.

### 3. Add Firestore rules
In Firebase → Firestore Database → Rules, use these starter rules, then publish. These allow authenticated users to read messages and create messages only as their own signed-in UID. They limit message size and basic fields. For a public website, add stronger anti-spam/moderation controls before sharing widely.

```text
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /rooms/{roomId}/messages/{messageId} {
      allow read: if request.auth != null;
      allow create: if request.auth != null
        && request.resource.data.uid == request.auth.uid
        && request.resource.data.name is string
        && request.resource.data.name.size() <= 24
        && request.resource.data.text is string
        && request.resource.data.text.size() > 0
        && request.resource.data.text.size() <= 600
        && request.resource.data.kind in ['user', 'bot'];
      allow update, delete: if false;
    }
  }
}
```

The bot reply is written under the same signed-in UID as the user who triggered it, so other people in the room can see it. It is a simple rule-based bot, not an AI model.

### 4. Publish with GitHub Pages
1. Create a new public repository named `websitechat`.
2. Upload `index.html` and `README.md` from this folder.
3. In the repo, open **Settings → Pages**.
4. Under Build and deployment, select **Deploy from a branch**, choose `main` and `/ (root)`, then Save.
5. GitHub will show your live `github.io` website URL after deployment.

### 5. Use WebsiteChat.Com as your domain
You must register `WebsiteChat.Com` with a domain registrar if it is available. Then configure the custom domain in GitHub Pages settings and add the DNS records GitHub specifies. I have not registered or checked availability of this domain.

## Important before inviting strangers
- This is a starter project, not a fully moderated production chat service.
- Anyone with access to the public room can read messages. Don't send passwords, addresses, or private information.
- Public anonymous chat can attract spam. Add rate limits, reporting, blocking, moderation, and abuse protection before promoting it widely.
- Bot replies are simple scripted responses. A true AI bot would need a server-side API endpoint; never put a private AI API key in `index.html`.
- This starter has one room (`general`). Multi-room support, user accounts, avatars, typing indicators, and message deletion can be added next.
